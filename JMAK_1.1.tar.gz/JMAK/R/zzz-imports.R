#' @importFrom stats coef lm cooks.distance nls setNames
#' @importFrom graphics abline plot
#' @importFrom ggplot2 ggplot aes geom_point geom_line geom_vline geom_abline geom_smooth annotate labs theme_minimal ggsave
NULL
